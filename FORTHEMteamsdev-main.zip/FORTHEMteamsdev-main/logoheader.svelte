<div class="presentationContainer">
	<div class="logo">
	<!-- logo -->
		<img src="/forthem_logo_text_color.svg" alt="logo FORTHEM" class="logo" />
	</div>
	<div class="presentation">
	<!-- presentation -->
		<h2>Embarquez pour l'Europe avec FORTHEM !</h2>
		<div>
			<p>FORTHEM, c'est notre « université européenne », une alliance entre 9 universités, en Allemagne, en Espagne, en Finlande, en France, en Italie, en Lettonie, en Norvège, en Pologne et en Roumanie. Elle rassemble plus de 229 000 étudiants et 30 000 salariés sur 21 campus et 148 instituts de recherche, pour étudier et travailler ensemble au-delà des frontières nationales.</p>
		</div>
	</div>
</div>

<style>
	.presentationContainer {
		background: var(--box-color);
		box-shadow: var(--box-shadow);
		border-radius: var(--radius);
		display: flex;
		flex-direction: row;
		margin: var(--margin) calc(var(--margin) * 2);
	}
	
	.logo { text-align: left; min-width: 320px; min-height: 170px; margin-right: 20px; }
	.logo img { max-width: 300px; height: auto; margin: 2em 0 2em 1em; }

	.presentation { 
		margin: var(--margin);
		padding-left: calc(var(--margin) * 2); 
		border-left: 2px solid var(--background-color); 
		vertical-align: middle;
		background-repeat: no-repeat;
		color: #000;
		border-radius: 0 20px 20px 0;
	}
	

	p { line-height: 1.4em; }

	@media screen and (max-width: 800px) {
		.presentationContainer { flex-direction: column; margin: var(--margin); }
		.presentation { padding-left: 0; }
		h2 { font-size: 1.2em; }
		p { font-size: 0.9em; }
		.logo { display: inline-block; height: 100%; vertical-align: middle; text-align: center; height: auto; }
		.logo img { max-width: 80%; margin: 2em 0 0 1em;  }
		.presentation { margin: 1.5em; border-left: 0; border-top: 2px solid var(--background-color); text-align: center; }
	}
</style>