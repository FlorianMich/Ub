<script>
	import { onMount } from 'svelte';
	import {MDCTabBar} from '@material/tab-bar';
	import './tabs.scss';
	import * as microsoftTeams from "@microsoft/teams-js";
	import Tab from './tab.svelte';
	export let tabsData;

	// DOM elements
	let mdcTabBar;
	let tabs;
	let buttons = new Array();
	
	// Dynamic classes and attributes values 
	const ariaSelected = (index) => (index === 0) ? 'true' : 'false';
	const tabIndex = (index) => (index === 0) ? '0' : '-1';
	const underlineButton = (index) => (index === 0) ? 'mdc-tab-indicator--active' : '';
	const hidePanel = (index) => (index === 0) ? '' : '';

	
	const element = document.querySelector('#element');
	const add = () => document.body.appendChild(element);
	const remove = () => element.remove();

	let firstLoadedIndex = 0;
	var previousIndex = firstLoadedIndex;
	var currentIndex = firstLoadedIndex;
	
	
	function displayPanel(index) {

		const tabsDom = tabs.children;
		
		for(let i=0;i<tabsDom.length;i++) {	
			if(tabsDom[i].style.display === 'block') { previousIndex = i; }
		}
		
		for(let i=0;i<tabsDom.length;i++) {
		
			if(i === index) {
				tabsDom[i].style.display = 'block';
				tabsDom[i].setAttribute('tabindex', '0');
				currentIndex = i;
			}
			else
			{
				tabsDom[i].style.display = 'none';
				tabsDom[i].setAttribute('tabindex', '-1');
			}
		}
		
		if(currentIndex>previousIndex) 
		{ 
			tabsDom[currentIndex].classList.remove('toLeft');
			tabsDom[currentIndex].classList.remove('toRight');
			tabsDom[currentIndex].classList.add('toRight');
		}
		else
		{
			tabsDom[currentIndex].classList.remove('toLeft');
			tabsDom[currentIndex].classList.remove('toRight');
			tabsDom[currentIndex].classList.add('toLeft');
		}

	}

	
	
	onMount(() => {
		const tabBar = new MDCTabBar(mdcTabBar);
		tabBar.listen('MDCTabBar:activated', function (event) {
		   displayPanel(event.detail.index);
		});
		
		buttons[1].click();
		buttons[1].blur();
		buttons[0].click();
		buttons[0].blur();
				
		microsoftTeams.initialize();

		microsoftTeams.getContext((context) => {
		
			if(context.userLicenseType === "Teacher") {
				buttons[0].click();
				buttons[0].blur();
				buttons[1].click();
				buttons[1].blur();
			}
			else
			{
				buttons[1].click();
				buttons[1].blur();
				buttons[0].click();
				buttons[0].blur();
			}
			
		});
		
		
		microsoftTeams.registerOnThemeChangeHandler((theme)=> {

		});
		
		
	});
	
</script>
<div class="container">
	<!-- buttons -->
	<div bind:this="{mdcTabBar}" class="mdc-tab-bar" role="tablist">
	  <div class="mdc-tab-scroller">
		<div class="mdc-tab-scroller__scroll-area">
		  <div class="mdc-tab-scroller__scroll-content">
		  
			{#each tabsData as tab, i}
				<button bind:this="{buttons[i]}" class="mdc-tab mdc-tab--active" role="tab" aria-selected="{ariaSelected(i)}" tabindex="{tabIndex(i)}">
				  <span class="mdc-tab__content">
					<span class="mdc-tab__text-label">{tab.title}</span>
				  </span>
				  <span class="mdc-tab-indicator {underlineButton(i)}">
					<span class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"></span>
				  </span>
				</button>
			{/each}

		  </div>
		</div>
	  </div>
	</div>

	<!-- panels -->
	<div bind:this={tabs}>

		{#each tabsData as tab, i}
			<div role="tabpanel" tabindex="{tabIndex(i)}" class="panel {hidePanel(i)}">

				{#if tab.content}
					{@html tab.content}
				{:else}
					<Tab id={tab.id} />
				{/if}
			</div>
		{/each}

	</div>

</div>

<style>

    .mdc-tab-bar { padding: 0; }
	.mdc-tab { letter-spacing: 0;  font-weight: normal; }
	.mdc-tab:focus { /* Some exciting button focus styles */ }
	.mdc-tab:focus:not(:focus-visible) {
	  /* Undo all the above focused button styles
		 if the button has focus but the browser wouldn't normally
		 show default focus styles */
	}
	.mdc-tab:focus-visible { background: var(--box-color); }	
	.mdc-tab:focus-visible span { color: #10a0cb; }
	.mdc-tab__text-label { color: var(--color); font-family: sans-serif; font-size: 1.4em; text-transform: none;}
	.mdc-tab-indicator .mdc-tab-indicator__content--underline { border-color: #10a0cb; margin: 0; }
	.mdc-tab-indicator .mdc-tab-indicator__content {
		transition: 0.25 transform cubic-bezier(0, 0, 0.2, 1);
	}

	.tabs { width: 100vw; height: 50vh; }
	.panel {  width: 100vw; height: 50vh; }
	.invisible { opacity: 0;}
	.container { margin-bottom: 30vh; }
	@media screen and (min-width: 800px) {
		.mdc-tab-bar { padding: 0 calc(var(--margin) * 2);}
		.mdc-tab { max-width: 150px; }
		.mdc-tab-indicator .mdc-tab-indicator__content--underline { border-color: #10a0cb; margin: 0 var(--margin); }	
		.mdc-tab-scroller__scroll-content { justify-content: flex-end; padding-right: 100px;}
	}
</style>