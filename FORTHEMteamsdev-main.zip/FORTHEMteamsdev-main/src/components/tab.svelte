<script>
	import { data } from '../data/store.js';
	import CardScrollable from './cardScrollable.svelte';
	import RectangleCardScrollable from './rectangleCardScrollable.svelte';
	import Card from './card.svelte';
	import RectangleCard from './rectangleCard.svelte';
	
	export let id;
	let menus = [];
	
	function shuffle(array) {
		for (let i = array.length - 1; i > 0; i--) {
			let j = Math.floor(Math.random() * (i + 1));
			[array[i], array[j]] = [array[j], array[i]];
		}
		return array;
	}
	
	for(let i=0;i<data.menus.length;i++)
	{
		if(data.menus[i].tab === id)
		{
			menus.push(data.menus[i]);
		}
	}


	
</script>

<br><br>
{#each menus as menu, i}
<nav aria-labelledby="menu-{menu.id}">
	<h2 id="menu-{menu.id}">{menu.title}</h2>

	{#if menu.card == 'card'}
		<CardScrollable>
			<ul>
			{#each menu.articles as article, j}	
					<li>
						<Card id={article} />
					</li>
			{/each}
			</ul>
		</CardScrollable>
	{/if}
	{#if menu.card == 'rectangleCard'}
		<RectangleCardScrollable>
			<ul>
			{#if menu.sorting === "random"}
				{#each shuffle(menu.articles) as article, j}
						<li>
							<RectangleCard id={article} />
						</li>
				{/each}
			{:else}
				{#each menu.articles as article, j}
						<li>
							<RectangleCard id={article} />
						</li>
				{/each}
			{/if}
			
			</ul>
	</RectangleCardScrollable>
	{/if}
	
</nav>
{/each}

<style>
	h2 { font-size: 1.2em; font-weight: normal; margin-left: calc(var(--margin) * 2); }
	
	@media screen and (max-width: 800px) {
		h2 { margin: var(--margin); }
	}

	ul { display: flex; gap: 20px; list-style: none; padding-right: 260px !important; }

</style>