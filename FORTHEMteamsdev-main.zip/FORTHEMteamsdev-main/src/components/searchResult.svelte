<script>
	import { router, openSearchPanel } from '../data/store.js';
	export let item;
	
	
	function openArticle() {
		openSearchPanel.set(false);
		$router.navigate(item.href.slug);
	}
	
	function openPanel() {
		openSearchPanel.set(true);
	}
	
	
	
</script>

<div class='card' on:click={openArticle} on:focus={openPanel} tabindex="0">
	<span class='picture' style='background: url(/img/{item.picture})'></span>
	<h2>{item.title}</h2>
	<p>{item.subtitle}</p>
</div>

<style>
	.card {
		position: relative;
		margin: 0;
		padding: 0.5em 0.5em 0.5em 6em;
		border-bottom: 1px solid #eee;
		border-radius: 4px;
		min-height: 5em;
		cursor: pointer;
		
	}
	
	.card:hover {
		background: rgba(0,0,0,0.05);
	}
	

	.card:hover h2 {
		transform: translateX(4px);
	}
	
	.card:hover p {
		transform: translateX(12px);
	}
	
	
	.card::after {
		clear: both;
		display: block;
	}

	.picture {
		position: absolute;
		width: 4.5em;
		height: 4.5em;
		left: 1em;
		top: 0.6em;
		border-radius: 50%;
		background-size: 170% !important;   
		background-position: 50% 50% !important;

	}

	h2 {
		margin: 15px 0 0.5em 10px;
		font-size: 16px;
        transition: transform 0.4s cubic-bezier(0, 0, 0.2, 1);
	}

	p {
		margin: 0 10px;
		font-size: 14px;
		transform: translate(0);
        transition: transform 0.4s cubic-bezier(0, 0, 0.2, 1);
	}
</style>