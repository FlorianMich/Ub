<script>
	import { linear, expoOut } from 'svelte/easing';
	import { fly, fade } from 'svelte/transition';
	import fadeScale from '../animations/svelte-transitions-fade-scale.js';
	import { data, openSearchPanel } from '../data/store.js';
	import SearchResult from './searchResult.svelte';
	
	let searchTerm = "";
	$: filteredList = data.articles.filter(article => article.title
							.toLowerCase()
							.normalize("NFD").replace(/\p{Diacritic}/gu, "")
							.indexOf(searchTerm.toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu, "")) !== -1 ||
						article.subtitle
							.toLowerCase()
							.normalize("NFD").replace(/\p{Diacritic}/gu, "")
							.indexOf(searchTerm.toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu, "")) !== -1 ||
						article.description
							.replace(/(<([^>]+)>)/gi, "")
							.toLowerCase()
							.normalize("NFD").replace(/\p{Diacritic}/gu, "")
							.indexOf(searchTerm.toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu, "")) !== -1) ;
	

	function openPanel() {
		if(searchTerm.length > 0)
		{
			openSearchPanel.set(true);
			
		}
		else
		{
			openSearchPanel.set(false);
		}
	}
	
	function closePanel() {
		openSearchPanel.set(false)
	}
	
	function resultLabel(numberOfResults) {
		if(numberOfResults == 0) { return "Aucun résultat"; }
		if(numberOfResults > 1) { return numberOfResults + " résultats :"; }
		if(numberOfResults == 1) { return "1 résultat :"; }
	}
	
</script>

<nav class="topBar">
	<div>
		<input bind:value={searchTerm} on:input={openPanel} on:focus={openPanel}  class="search" placeholder="Rechercher" aria-label="Recherche" />
		{#if $openSearchPanel}
			<div class="searchPanel" in:fadeScale={{delay: 0,duration: 500, easing: expoOut,baseScale: 0.99}} out:fadeScale={{delay: 0,duration: 50, easing: linear, baseScale: 0.99}}>
				<button class="closeButton" aria-label="Fermer la recherche" on:click={closePanel} transition:fly>&#10006;</button>
				{#if searchTerm.length > 1}
					
					<span>{resultLabel(filteredList.length)}</span>
					{#if filteredList.length > 0}<hr>{/if}
					{#each filteredList as item}
						<div><SearchResult item={item} /></div>
					{/each}
				{/if}
	
				<span></span>
			</div>
			
		{/if}
		
	</div>
	<div class="configuration">
		<button aria-label="Mode sombre">				
		</button>
		<button aria-label="Préférences" class="settings">
			<img class="aboutIcon" src="/outline_help_outline_white_24dp.png" alt="" aria-hidden="true">
		</button>						
	</div>
</nav>


<style>
	.topBar {
		background: var(--gradient);
		box-shadow: var(--box-shadow);
		border-radius: var(--radius);
		display: grid; 
		grid-template-columns: 1fr 1fr;
		grid-auto-flow: row;
		padding: 10px;
		margin: calc(var(--margin)) calc(var(--margin)) 0 calc(var(--margin));	
	}

	.search { 
		/* padding: 5px 5px 5px 30px;*/
		position: absolute;
		border: 2px solid rgba(255, 255, 255, 0);
		width: 600px;
		padding: 7px;
		padding-left: 40px;
		border-radius: 14px;
		background: url('/outline_search_white_24dp.png') no-repeat 9px center; 
		color: #fff;
		outline: none;
		transition: all 0.8s cubic-bezier(0, 0, 0.2, 1);
		z-index: 4; 
	}

	.settings img {  }
	
	.search::placeholder {
		color: #fff;
		opacity: 1;
		transition: all 0.4s cubic-bezier(0, 0, 0.2, 1);	
	}

	.search:focus {
		/*outline: 2px dotted #fff;*/
		border: 2px solid rgba(255, 255, 255, 1);
	}

	.search:focus::placeholder {
		opacity: 0;
		transform: translateX(-7px);
	}

	
	.configuration {
		/* text-align: right; */
		max-height: 33px;
		text-align: right;
		padding-right: 10px;
	}

	.configuration button {
		padding: 4px;
		background: none;
		outline: none;
		border: none;
	}
	
	.searchPanel { position: absolute; top: 62px; left: 40px; width: 625px;  box-shadow: var(--box-shadow-xl); background: var(--box-color); color: var(--color);  z-index: 4;  max-height: 80vh; overflow-y: scroll; padding: 20px 0 120px 0;
	}
	
	.searchPanel span { margin: 1em; font-weight: bold;}
	hr { border: 0; height: 1px; background: #eee; }
	

	.closeButton { 	
		background: none; 
		border: none;
		position: absolute;
		top: 15px;
		right: 20px;
		font-size: 1.2em;
		cursor:pointer;
		color: var(--color);
		z-index: 13;
	}
	
	.aboutIcon { height: 24px; width: auto;  }
	
	hr { border-top: 1px solid #eee; margin-top: 20px; margin-bottom: 0;  }
	@media screen and (max-width: 800px) {
		.topBar { margin: 0; border-radius: 0; top: 0;}
		.search { width: 200px; }
		.searchPanel { top: 54px; left: 0; right: 0; bottom: 0; width: 100vw;}
		.closeButton { 	
			top: 1em;
			right: 22px;
			font-size: 1em;
		}
			
	}
	

</style>