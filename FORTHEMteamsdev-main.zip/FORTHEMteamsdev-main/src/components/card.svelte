<script>
	import { onMount } from 'svelte';
	import { router, data, count, currentArticleId, currentArticle } from '../data/store.js';
	
	export let id;
	let article = data.indexedArticles[id];	

	function externalLink () {
		if(article.href.external) { return true; } else { return false; }
	}
	
	
</script>

<div class="card">
	{#if externalLink() === true}
		<a href="{article.href.external}" data-id="{article.id}" target="_blank" rel="noopener noreferrer">
			<div>
				<div class="overlay"></div>
				<div class="card-header" style="background: url('/img/{article.picture}');"></div>
				<div class="card-body">
					<h3>{article.title}</h3> 
					<p>
						{article.subtitle}
					</p>
				</div>
			</div>
		</a>
	{:else}
		<a href="{article.href.slug}" data-id="{article.id}" data-navigo>
			<div>
				<div class="overlay"></div>
				<div class="card-header" style="background: url('/img/{article.picture}');"></div>
				<div class="card-body">
					<h3>{article.title}</h3> 
					<p>
						{article.subtitle}
					</p>
				</div>
			</div>
		</a>
	{/if}	
</div>



<style>
	.card { 
		position: relative; 
		background: var(--box-color);
		box-shadow: var(--box-shadow); 
		border-radius: var(--radius); 	
		width: 200px; 
		height: 190px;
		margin: 0 10px 0 0; 
		text-align: center;	
		transition: transform 0.15s cubic-bezier(0, 0, 0.2, 1);
		cursor: pointer;
		
	}
	
	.card:hover {
	  transform: scale(1.1);
	}
	
	.overlay { 
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 100px;
		background: linear-gradient(45deg, #10cba0, #10a0cb);
		opacity: 0;
		transition: opacity 0.15s cubic-bezier(0, 0, 0.2, 1);
		border-radius: 20px 20px 0 0;
		z-index: 1;
	}
	
	.card:hover .overlay {
	  opacity: 0.9;
	}		

	.card:hover .overlay::after {
	  content: "";
	  background-image: url('/forthem-logo-white.svg');
	  background-size: 100% 100%;
	  display: inline-block;
	  position: absolute;
	  top: 10px;
	  left: 0;
	  opacity: 1;
	  height: 80px;
	  width: 100%;
	  z-index: 3;
	  animation: 0.15s moveIn cubic-bezier(0, 0, 0.2, 1);
	}

	.card-header {  
		z-index: 0; 
		height: 100px; 
		background-size: cover !important; 
		border-top-left-radius: 20px; 
		border-top-right-radius: 20px; 
		background-position: center;
	}

	.card-body { 
		position: relative; 
		z-index: 1; 
		padding:0 20px;
	}

	.card-body h3 {
		font-size: 16px;
		transition: transform 0.2s cubic-bezier(0, 0, 0.2, 1), opacity 0.1s cubic-bezier(0, 0, 0.2, 1);
		font-weight: normal;
	}

	.card:hover h3 {
		opacity: 0;
		transform: translate3d(0,-25px,0);
	}

	.card-body p {

		font-size: 13.5px;
		height: 70px;
		line-height: 1.5em; 
		overflow: hidden;
		position: absolute;
		top: -10px;
		left: 0;
		right: 0;
		padding: 10px 20px 20px 20px;
		transform: translate3d(0,0,0);
		transition: transform 0.15s cubic-bezier(0, 0, 0.2, 1), opacity 0.15s cubic-bezier(0, 0, 0.2, 1);
		opacity: 0;
	}


	.card:hover .card-body p {
	  opacity: 1;
	  transform: translate3d(0,-17px,0);
	}

	a { 
		text-decoration: none; 
		color: inherit;  
		outline: none;
	}
</style>