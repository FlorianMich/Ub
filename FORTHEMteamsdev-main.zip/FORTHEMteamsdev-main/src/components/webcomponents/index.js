import FluidIframe from 'fluid-iframe';
customElements.define('fluid-iframe', FluidIframe);