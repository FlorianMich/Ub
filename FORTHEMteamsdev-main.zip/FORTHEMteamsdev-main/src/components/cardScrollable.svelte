<script>
	import { onMount } from 'svelte';
	let container;
	let step = 300;
	
	onMount(() => {
		step = container.offsetWidth / 2;
	});
	
</script>

<div class="scrollable">
	<div class="container" bind:this="{container}" >
		<slot></slot>
	</div>

	<div class="navigation">
		<button class="prev button" aria-hidden="true" on:click={container.scrollLeft -= step}><i class="arrow left"></i></button>
		<button class="next button" aria-hidden="true" on:click={container.scrollLeft += step}><i class="arrow right"></button>
	</div>
</div>
<style>

	.button { background: transparent; border: none; cursor: pointer; border-radius: 50%; padding: 10px; opacity: 0.6; transition: all 0.25s var(--easing); }
	.container {display: flex; overflow-y: hidden; overflow-x: auto; scroll-behavior: smooth; padding: 0; width: 100vw; }
	.container::-webkit-scrollbar {display: none;}
	
	.arrow {
	  border: solid var(--primary);
	  border-width: 0 3px 3px 0;
	  display: inline-block;
	  padding: 14px;
	}

	.right {
	  transform: rotate(-45deg);
	  -webkit-transform: rotate(-45deg);
	}

	.left {
	  transform: rotate(135deg);
	  -webkit-transform: rotate(135deg);
	}

	.navigation { position: relative; top: -136px; z-index: 2; }
	.button:hover {opacity: 1;}

	.prev { position: absolute; top: 4px; left: 40px; opacity: 0; transition: opacity 0.4s cubic-bezier(0, 0, 0.2, 1); }
	.next { position: absolute; top: 4px; right: 60px; opacity: 0; transition: opacity 0.4s cubic-bezier(0, 0, 0.2, 1); }
	.scrollable:hover button { opacity: 1; } 
	
	@media screen and (max-width: 800px) {
		button { display: none; }
	}
</style>