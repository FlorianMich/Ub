<script>
	import { onMount } from 'svelte';
	import { router, data, count, currentArticleId, currentArticle } from '../data/store.js';
	
	export let id;
	let article = data.indexedArticles[id];	

	function externalLink () {
		if(article.href.external) { return true; } else { return false; }
	}
	
	
</script>

<div class="card">
	{#if externalLink() === true}
		<a href="{article.href.external}" data-id="{article.id}" target="_blank" rel="noopener noreferrer">
			<div>
				<div class="overlay" style="background-image: linear-gradient(45deg, rgba(16,203,160,0.75), rgba(16,160,203,0.75)), url('/img/{article.picture}');  background-size: cover !important;"></div>
				<div class="card-header"></div>
				<div class="card-body">
					{#if article.thumb !== ""}
						<span class='picture' style='background: url(/img/{article.thumb}); background-size: contain;'></span>
					{:else}
						<span class='picture' style='background: url(/img/{article.picture});'></span>
					{/if}
						<h3>{article.title}</h3> 
						<p>
							{article.subtitle}
						</p>
					
				</div>
			</div>
		</a>
	{:else}
		<a href="{article.href.slug}" data-id="{article.id}" data-navigo>
			<div>
				<div class="overlay" style="background-image: linear-gradient(45deg, rgba(16,203,160,0.75), rgba(16,160,203,0.75)), url('/img/{article.picture}');  background-size: cover !important;"></div>
				<div class="card-header"></div>
				<div class="card-body">
					{#if article.thumb !== ""}
						<span class='picture' style='background: url(/img/{article.thumb}); background-size: contain;'></span>
					{:else}
						<span class='picture' style='background: url(/img/{article.picture});'></span>
					{/if}
						<h3>{article.title}</h3> 
						<p>
							{article.subtitle}
						</p>
					
				</div>
			</div>
		</a>
	{/if}	
</div>



<style>
	.card { 
		position: relative; 
		background: var(--box-color);
		box-shadow: var(--box-shadow-l); 
		border-radius: var(--radius); 	
		min-width: 200px; 
		height: 90px;
		margin: 0 10px 0 0; 
		text-align: center;	
		transition: transform 0.15s cubic-bezier(0, 0, 0.2, 1);
		cursor: pointer;	
	}
	
	.card:hover {
	  transform: scale(1.1);
	}
	
	.picture {
		position: absolute;
		width: 50px;
		height: 50px;
		left: 20px;
		top: 10px;
		/*border-radius: 50%;*/


	}

	.overlay { 
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 92px;
		opacity: 0;
		transition: opacity 0.15s cubic-bezier(0, 0, 0.2, 1);
		border-radius: 20px;
		z-index: 1;
		filter: grayscale(1);
	}
	
	.card:hover .overlay {
	  opacity: 0.98;
	  filter: grayscale(0);
	}		

	.card:hover .overlay::after {
	  content: "";
	  display: inline-block;
	  position: absolute;
	  top: 10px;
	  left: 0;
	  opacity: 1;
	  height: 60px;
	  width: 100%;
	  z-index: 3;
	  animation: 0.15s moveIn cubic-bezier(0, 0, 0.2, 1);
	  
	}

	.card-header {  
		z-index: 0; 
		height: 90px; 
		background-size: contain !important; 
		border-radius: 20px; 
		background-position: center;
	}

	.card-body { 
		position: absolute; 
		top: 10px;
		z-index: 1; 
		padding:0 20px;
		
	}

	.card-body h3 {
		font-size: 16px;
		transition: transform 0.2s cubic-bezier(0, 0, 0.2, 1), opacity 0.1s cubic-bezier(0, 0, 0.2, 1);
		font-weight: normal;
		margin: 15px 0 0 60px;
	}

	.card:hover h3 {
		opacity: 0;
		transform: translate3d(0,-25px,0);
	}

	.card-body p {
		color: #fff;
		font-size: 13.5px;
		height: 90px;
		line-height: 1.5em; 
		overflow: hidden;
		position: absolute;
		top: -14px;
		left: 70px;
		right: 0;
		padding: 30px 20px 20px 20px;
		transform: translate3d(0,0,0);
		transition: transform 0.15s cubic-bezier(0, 0, 0.2, 1), opacity 0.15s cubic-bezier(0, 0, 0.2, 1);
		opacity: 0;
	}


	.card:hover .card-body p {
	  opacity: 1;
	  transform: translate3d(0,-17px,0);
	}

	a { 
		text-decoration: none; 
		color: inherit;  
		outline: none;
	}
</style>