import { writable, derived } from 'svelte/store';
import Data from './fr.json';

Data.indexedArticles = {};
for(let i=0;i<Data.articles.length;i++) {
	
	let tmp = Data.articles[i];
	if(i==0) { tmp.previous = null; tmp.next = Data.articles[i+1].id; }
	if(i>0 && i<Data.articles.length-1) { tmp.previous = Data.articles[i-1].id; tmp.next = Data.articles[i+1].id; }
	if(i == Data.articles.length-1) { tmp.previous = Data.articles[i-1].id; tmp.next = null; }
	Data.indexedArticles[Data.articles[i].id] = tmp;
}


export const data = Data;

export const router = writable()

export const open = writable(false);
export const openSearchPanel = writable(false);

export const count = writable(0);

export const currentArticleId = writable(1);
export const currentArticle = derived(
	currentArticleId,
	$currentArticleId => Data.indexedArticles[$currentArticleId]
);


export const previousArticle = derived(
	currentArticle,
	$currentArticle => Data.indexedArticles[$currentArticle.previous]
);

export const nextArticle = derived(
	currentArticle,
	$currentArticle => Data.indexedArticles[$currentArticle.next]
);

