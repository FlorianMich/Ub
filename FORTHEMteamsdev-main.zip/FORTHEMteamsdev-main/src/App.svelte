<script>
	import { onMount } from 'svelte';
	import { data, router, open, count, currentArticleId, currentArticle, previousArticle, nextArticle  } from './data/store.js';
	import Navigo from 'navigo';
	import { fade } from 'svelte/transition';
	import { linear, expoOut } from 'svelte/easing';
	import './components/webcomponents/index.js';

		
	/*import fadeScale from './animations/svelte-transitions-fade-scale.js';*/

	import Home from './pages/home.svelte';
	import Article from './pages/article.svelte';


	let homeContainer, article, articleContainer;
	
	function hrefToId(href) {
		let match = data.articles.filter(article => article.href.slug === href);
		
		if(match.length>0) 
		{ $currentArticleId = match[0].id;  } 
		else // 404 route
		{ 
			// defaults to article with id number 1 (with no error message)
		}
	}

	$router = new Navigo('/');
	
	$router.on('', function (route) {
		$open = false;
	});
	
	$router.on('/:page', function (route) {
		count.update(n => n + 1);
		$open = true;	
		hrefToId(route.url);
	});

	$router.on('/:root/:page', function (route) {
		count.update(n => n + 1);
		$open = true;	
		hrefToId(route.url.split('/')[1]);
	});
	
	$router.resolve();
	
	
	
</script>


<div class="main">
	{#if $open === false}
		{#key $open}
			<div class="home" in:fade="{{ duration: 175, delay: 175, easing: linear }}" out:fade="{{  duration: 175, delay: 0, easing: expoOut }}">
				<Home />
			</div>
		{/key}
	{:else}
		{#key $open}
			<div class="article" in:fade="{{ duration: 175, delay: 175, easing: linear }}" out:fade="{{  duration: 175, delay: 0, easing: expoOut }}">
				<Article />
			</div>
		{/key}
	{/if}
</div>




<style>
	.home { position: absolute; top: 0; left: 0; right: 0;}
	.article { position: absolute; top: 0; left: 0; right: 0; }
	
	.home, .article {  padding-bottom: 100px; }

	
	
	
</style>