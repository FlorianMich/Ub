<script>
	import { onMount } from 'svelte';
	import { data, router } from '../data/store.js';
		
	import Topnav from '../components/topnav.svelte';
	import Logoheader from '../components/logoheader.svelte';
	import Tabs from '../components/tabs.svelte';
	
	let contentContainer;
	
	onMount(() => {
		$router.updatePageLinks();
	});
	
</script>

<div bind:this={contentContainer}>
	<Topnav />
	<Logoheader />
	<Tabs tabsData={data.tabs} />
</div>
