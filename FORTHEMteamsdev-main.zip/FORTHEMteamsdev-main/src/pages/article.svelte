<script>
	import { onMount } from 'svelte';
	import { fade } from 'svelte/transition';
	import { linear, expoOut } from 'svelte/easing';
	import { data, router, open, currentArticle, previousArticle, nextArticle, count } from '../data/store.js';
	import Navigo from 'navigo';
	
	let contentContainer;
	$: share = { title: "FORTHEM - " + $currentArticle.title, text: $currentArticle.subtitle, url: 'https://developer.mozilla.org'};
	
	function closePanel() {
		$router.navigate('/');
		open.set(false);
	}

	function previous() {
		$router.navigate($previousArticle.href.slug);
	}
	
	function next() {	
		$router.navigate($nextArticle.href.slug);
	}

</script>

<div class="content">

	<div class="desktop">
		<div class="titleBar {$count % 2 == 0 ? 'odd' : ''}">
			<h1 class="title {$count % 2 == 0 ? 'odd' : ''}">{$currentArticle.title}</h1>
		</div>
		<div class="subtitleBar box white-text {$count % 2 == 0 ? 'odd' : ''}">
			<h2 class="subtitle {$count % 2 == 0 ? 'odd' : ''}">{$currentArticle.subtitle}</h2>
		</div>
		<button class="closeButton" aria-label="Retour au menu" on:click={closePanel}>&#10006;</button>
		<div class="thumb {$count % 2 == 0 ? 'odd' : ''}" style="background: url('/img/{$currentArticle.picture}');"></div>
		<div bind:this={contentContainer} class="contentContainer">
			{#key $currentArticle}
				<div in:fade="{{ duration: 300, delay: 300, easing: linear }}"
		out:fade="{{  duration: 300, delay: 0, easing: expoOut }}" >
				{#each $currentArticle.content as block}
					{#if block.component === 'html'}
						{@html block.content}
					{/if}
				{/each}
				
				<div class="cta">
					<!--a class="round-cta share-button box" id="shareButton" on:click={navigator.share(share)}></a-->
					{#if $currentArticle.href.more}
						<a href="{$currentArticle.href.more.href}" class="rectangle-cta know-more-button box rounded" target="_blank" rel="noopener noreferrer"><span>{$currentArticle.href.more.label}</span></a>
					{/if}
				</div>
			</div>{/key}
		</div>
		
		<div class="navigation">
			<div class="navigationContainer">
				<div class="previousArrowContainer">
					{#if $previousArticle}
						{#key $previousArticle.title} 
							<button on:click={previous} class="previousArrow" in:fade="{{ duration: 300, delay: 300, easing: linear }}" out:fade="{{  duration: 300, delay: 0, easing: expoOut }}"><i class="primaryArrow left"></i><span class="label desktop">{$previousArticle.title}</span></button>
						{/key}
					{/if}
				</div>
				<div class="nextArrowContainer">
					{#if $nextArticle}
						{#key $nextArticle.title} 
							<button on:click={next} class="nextArrow" in:fade="{{ duration: 300, delay: 300, easing: linear }}" out:fade="{{  duration: 300, delay: 0, easing: expoOut }}"><span class="label desktop">{$nextArticle.title}</span><i class="primaryArrow right"></i></button>
						{/key}
					{/if}
				</div>
			</div>
		</div>
	</div>
	
	
	<div class="mobile">
		<div class="titleBar {$count % 2 == 0 ? 'odd' : ''}">
			<!--button class="backButton" aria-label="Retour au menu" on:click={closePanel}><i class="whiteArrow left"></i></button-->
			<h1 class="title {$count % 2 == 0 ? 'odd' : ''}">{$currentArticle.title}</h1>
			<button class="closeButton" aria-label="Retour au menu" on:click={closePanel}>&#10006;</button>
		</div>
		<div class="subtitleBar box white-text {$count % 2 == 0 ? 'odd' : ''}">
		</div>

		<div bind:this={contentContainer} class="contentContainer">
			
			<div class="subtitleMobile">
					<h2 class="subtitle  {$count % 2 == 0 ? 'odd' : ''}">{$currentArticle.subtitle}</h2>
			</div>
		
			{#key $currentArticle}
			<div in:fade="{{ duration: 300, delay: 300, easing: linear }}"
			out:fade="{{  duration: 300, delay: 0, easing: expoOut }}">
				<div class="thumb" style="background: url('/img/{$currentArticle.picture}');" in:fade="{{ duration: 300, delay: 300, easing: linear }}"></div>
				
				<div class="dynamicContent">
					{#each $currentArticle.content as block}
						{#if block.component === 'html'}
							{@html block.content}
						{/if}
					{/each}
					
					<div class="cta">
						<!--a class="round-cta share-button box" id="shareButton"></a-->
						{#if $currentArticle.href.more}
							<a href="{$currentArticle.href.more.href}" class="rectangle-cta know-more-button box rounded" target="_blank" rel="noopener noreferrer"><span>{$currentArticle.href.more.label}</span></a>
						{/if}
					</div>
					
				</div>
			</div>{/key}
		</div>
		
		<div class="navigation">
			<div class="navigationContainer">
				<div class="previousArrowContainer">
					{#if $previousArticle}
						{#key $previousArticle.title} 
							<button on:click={previous} class="previousArrow" in:fade="{{ duration: 300, delay: 300, easing: linear }}" out:fade="{{  duration: 300, delay: 0, easing: expoOut }}"><i class="primaryArrow left"></i></button>
						{/key}
					{/if}
				</div>
				<div class="nextArrowContainer">
					{#if $nextArticle}
						{#key $nextArticle.title} 
							<button on:click={next} class="nextArrow" in:fade="{{ duration: 300, delay: 300, easing: linear }}" out:fade="{{  duration: 300, delay: 0, easing: expoOut }}"><i class="primaryArrow right"></i></button>
						{/key}
					{/if}
				</div>
			</div>
		</div>
	</div>
</div>


<style>
	.content { position: absolute; top: 0; left: 0; right: 0;  }
	.content::after { content: ""; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: url('/forthem_background_logo.svg') no-repeat bottom 50% right -312px, var(--background-color); z-index: -1;  }
	
	.titleBar {
		background-image: var(--green-to-blue);
		top: 0; left:0; right: 0; height: 70px;
		position: fixed;
		z-index: 1;
	}

	.titleBar::after {
		content: "";
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-image: var(--blue-to-green);
		opacity: 0;
		transition: opacity 0.8s cubic-bezier(0, 0, 0.2, 1);

	}

	.titleBar.odd::after {
		opacity: 1;
	}

	.title { 
		font-size: 1.5em; z-index: 1; position: relative; margin: 20px 2.5em 0 35px; 
		transition: all 0.6s cubic-bezier(0, 0, 0.2, 1);
		transform: translate(0);
		color: #fff;
	}
	
	.title.odd {
		transform: translate(20px);
	}

	.desktop { display: block;}
	.mobile { display: none;}
	.backButton {
		
	}
	
	.closeButton {
		background: none; 
		border: none;
		position: fixed;
		top: 0.7em;
		right: 2.5em;
		font-size: 1.5em;
		cursor:pointer;
		color: #fff;
		z-index: 13;
	}

	.thumb { 
		width: 10em; 
		height: 10em;
		position: fixed;
		right: 8em;
		top: 2em;
		border-radius: 50%;
		transform: scale(1.1) translateX(5%) translateY(0);
		transition: all 0.6s cubic-bezier(0, 0, 0.2, 1);
		z-index: 2;
		background-size: cover !important;
		background-position: center !important;
	}
	
	.thumb.odd {
		border-radius: 20px;
		transform: scale(1) translateX(0) translateY(-5%);
	}
	
	.subtitleBar {
		background: var(--lightblue);
		position: fixed;
		top: 70px; left: 0; right: 0; height: 60px;
		z-index: 1;
	}
	
	.subtitleBar::after {
		content: "";
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background: var(--lightgreen);
		opacity: 0;
		transition: opacity 0.8s cubic-bezier(0, 0, 0.2, 1);
	}
	
	.subtitleBar.odd::after {
		opacity: 1;
	}

	.subtitle { 
		font-size: 1.3em; font-weight: normal;
		transition: all 0.6s cubic-bezier(0, 0, 0.2, 1);
		transform: translate(20px);
		position: relative;
		color: #fff;
		margin: 18px 2.5em 0 35px; 
		z-index: 3;
	}

	.subtitle.odd {
		transform: translate(0);
	}
	
	.contentContainer {
		padding: 170px 410px 100px 80px;
		min-height: 120vh;
		z-index: -1;
		font-size: 18px;
		line-height: 28px;

	}

	.navigation {
		background: var(--background-color);
		position: fixed;
		bottom: 0;
		left: 0;
		right: 0;
	}
	
	.navigationContainer {
		background: var(--box-color);
		box-shadow: var(--box-shadow);
		border-radius: var(--radius);
		margin: 0 2em 2em 2em;
		display: grid;
		grid-template-columns: 1fr 1fr;
		grid-auto-flow: row;
		user-select: none; 
		height: 40px;
	}

	
	.navigationContainer button {
		text-decoration: none;
		color: #000;
		background: none;
		border: none;
		
	}

	.previousArrow, .nextArrow {
		opacity: 1;
		font-size: 1.2em;
		cursor: pointer;
		width: 100%;
		padding: 10px;
	}
	
	.previousArrow { text-align: left; }
	.nextArrow { text-align: right;  }

	.previousArrowContainer { border-right: 1px solid #eee;  }
	
	@keyframes fadeIn {
		0% { opacity: 1; }
		50% { opacity: 0; }
		100% { opacity: 1; }
	}
	
	.primaryArrow { border: solid var(--primary);  border-width: 0 3px 3px 0; display: inline-block; padding: 5px; margin: 0 10px; }
	.label { display: inline-block; margin: 0 10px; }
	.whiteArrow { border: solid #fff;  border-width: 0 3px 3px 0; display: inline-block; padding: 5px;}
	
	.right {
	  transform: rotate(-45deg);
	  -webkit-transform: rotate(-45deg);
	}

	.left {
	  transform: rotate(135deg);
	  -webkit-transform: rotate(135deg);
	}
	
	@media screen and (max-width: 800px) {
	
		.desktop { display: none;}
		.mobile { display: block;}
	
		.titleBar {
			top: 0; left:0; right: 0; height: 53px;
			position: fixed;
			z-index: 1;
			text-align: center;
		}
		
		.title { 
			font-size: 20px; z-index: 1; position: relative; margin: 16px 0 0 0;
			transform: translate(-20px);
		}
		
		.title.odd {
			transform: translate(0);
		}
		
		.closeButton {
			display: block;
			background: none; 
			border: none;
			position: fixed;
			top: 9px;
			right: 16px;
			font-size: 20px;
			cursor:pointer;
			z-index: 3;
			color: #fff;
		}

		.thumb { 
			position: relative;
			top: 0;
			left: 0;
			border-radius: 20px;
			z-index: 0;
			height: 200px;
			width: 100%;
			transition: none;
			transform: none;
			margin-bottom: 30px; 
		}
		
		
		.content::after { background: none;}
		.dynamicContent { margin-bottom: 320px; }
		.dynamicContent::after { content: ""; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: url('/forthem_background_logo.svg') no-repeat bottom 100px right -312px; z-index: -1; }

		.subtitle { color: var(--color); font-size: 18px; line-height: 26px; font-weight: bold; margin: 26px 20px 30px 0; z-index: 0; }

		.subtitleBar {
			top: 53px; left: 0; right: 0; height: 8px;
		}
		
		
		.contentContainer {
			padding: 60px 30px 60px 30px;
			font-size: 16px;
			line-height: 20px;
		}

		
		.navigation {
			background: var(--background-color);
			position: fixed;
			bottom: 0;
			left: 0;
			right: 0;
		}
		
		.navigationContainer {
			background: var(--box-color);
			border-radius: 0;
			margin: 0 0 0 0;
			display: grid;
			grid-template-columns: 1fr 1fr;
			grid-auto-flow: row;
			user-select: none; 
		}

		
		.navigationContainer button {
			text-decoration: none;
			color: #000;
			background: none;
			border: none;
			display: inline-block;
			
		}

		.previousArrow, .nextArrow {
			opacity: 1;
			font-size: 1.2em;
			cursor: pointer;
			width: 100%;
			padding: 10px;
		}
		
		.previousArrow { text-align: right; }
		.nextArrow { text-align: left;  }

		.previousArrowContainer { border-right: 1px solid #eee;  }

	}
	

</style>