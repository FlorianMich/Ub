<script>
	import 'simplebar';
	import 'simplebar/dist/simplebar.css';
	let slots = $$props.$$slots;
</script>

{#if slots}
<div class="wrapper">
	{#if slots.header}
	<div class="header">
		<header>
			<slot name="header"></slot>
		</header>
	</div>
	{/if}
	{#if slots.main}
	<main class="content" aria-hidden="true">
		<div class="scrollable" aria-hidden="true" data-simplebar>
			<slot name="main"></slot>
			<div class="spacer"></div>
		</div>
	</main>
	{/if}
	{#if slots.footer}
	<footer>
		<slot name="footer"></slot>
	</footer>
	{/if}	
</div>
{/if}
		
<style>
	.wrapper {
	  height: 100%;
	  display: flex;
	  flex-direction: column;
	}
	.content {
	  flex: 1;
	  overflow: hidden;
	}
	
	.spacer { height: 50px; }
	.scrollable { height: calc(100vh - 70px); overflow-x: hidden; scroll-behavior: smooth; }
	@media screen and (max-width: 800px) {
		.scrollable { height: calc(100vh - 53px);}
	}
</style>